
var inputString = document.getElementById("word").value;
var textTrue = "It's a palindrome!";
var textFalse = "Sorry, that's not a palindrome.";

//function that return true if the word is palindrome and false if it is not
function isPalindrome(inStr) {
  for (let i = 0; i < inStr.length/2; i += 1) {
    if (inStr[i] !== inStr[inStr.length - 1 - i]) {
      return false;
    }
  }
  return true;
}
function clickFunction() {
    var inputString = document.getElementById("word").value;
  if (isPalindrome(inputString)) {
    document.write(textTrue);
  } else {
    document.write(textFalse);
  }
}
    



var x;
function table(x) {
    var x = document.getElementById("text").value;
    for (a = 1; a <= 10; a++) {
        console.log(x + " * " + a + ' = ' + x * a);
    }
}

function bubble_Sort(a)
{
    var swapp;
    var n = a.length-1;
    var x=a;
    do {
        swapp = false;
        for (var i=0; i < n; i++){
            if (x[i] < x[i+1]){
               var temp = x[i];
               x[i] = x[i+1];
               x[i+1] = temp;
               swapp = true;
            }
        }
        n--;
    } while (swapp);
 return x; 
}
console.log(bubble_Sort([1,6,4,3,2,4,5,6,6]));